/**
 * Directory Registry System for Auto-Bolt Chrome Extension
 * Manages the master directory list with smart filtering and lookup capabilities
 */

class DirectoryRegistry {
    constructor() {
        this.directories = [];
        this.metadata = {};
        this.initialized = false;
        this.filterCache = new Map();
    }

    /**
     * Initialize the registry with the master directory list
     */
    async initialize() {
        try {
            console.log('🏗️ Initializing Directory Registry...');
            
            // Load master directory list
            const response = await fetch(chrome.runtime.getURL('directories/master-directory-list.json'));
            if (!response.ok) {
                throw new Error(`Failed to load directory list: ${response.status}`);
            }
            
            const data = await response.json();
            this.directories = data.directories || [];
            this.metadata = data.metadata || {};
            
            // Normalize directory data for consistent processing
            this.normalizeDirectories();
            
            this.initialized = true;
            console.log(`✅ Directory Registry initialized with ${this.directories.length} directories`);
            
            return {
                success: true,
                totalDirectories: this.directories.length,
                metadata: this.metadata
            };
            
        } catch (error) {
            console.error('❌ Failed to initialize Directory Registry:', error);
            throw new Error(`Registry initialization failed: ${error.message}`);
        }
    }

    /**
     * Normalize directory data to ensure consistent field structure
     */
    normalizeDirectories() {
        this.directories = this.directories.map(dir => {
            // Ensure all required fields exist
            const normalized = {
                id: dir.id,
                name: dir.name,
                url: dir.url,
                category: dir.category || 'unknown',
                priority: dir.priority || 'medium',
                submissionUrl: dir.submissionUrl || dir.url,
                difficulty: dir.difficulty || 'medium',
                estimatedTime: dir.estimatedTime || 300,
                
                // Normalize field mapping
                fieldMapping: dir.fieldMapping || {},
                
                // Normalize requirements
                requirements: dir.requirements || [],
                
                // Normalize boolean flags
                hasAntiBot: Boolean(dir.hasAntiBot),
                requiresLogin: Boolean(dir.requiresLogin),
                
                // Additional metadata
                monthlyTraffic: dir.monthlyTraffic,
                domainAuthority: dir.domainAuthority,
                submissionFee: dir.submissionFee
            };
            
            return normalized;
        });
    }

    /**
     * Get all directories with optional filtering
     */
    getDirectories(filters = {}) {
        const cacheKey = JSON.stringify(filters);
        
        // Check cache first
        if (this.filterCache.has(cacheKey)) {
            return this.filterCache.get(cacheKey);
        }
        
        let filtered = [...this.directories];
        
        // Apply filters
        if (filters.category) {
            filtered = filtered.filter(dir => 
                dir.category === filters.category
            );
        }
        
        if (filters.priority) {
            const priorities = Array.isArray(filters.priority) ? filters.priority : [filters.priority];
            filtered = filtered.filter(dir => 
                priorities.includes(dir.priority)
            );
        }
        
        if (filters.difficulty) {
            const difficulties = Array.isArray(filters.difficulty) ? filters.difficulty : [filters.difficulty];
            filtered = filtered.filter(dir => 
                difficulties.includes(dir.difficulty)
            );
        }
        
        if (filters.excludeAntiBot) {
            filtered = filtered.filter(dir => !dir.hasAntiBot);
        }
        
        if (filters.excludeLogin) {
            filtered = filtered.filter(dir => !dir.requiresLogin);
        }
        
        if (filters.excludeFees) {
            filtered = filtered.filter(dir => 
                !dir.submissionFee || 
                dir.submissionFee === '$0' || 
                dir.submissionFee === 'Free'
            );
        }
        
        if (filters.maxEstimatedTime) {
            filtered = filtered.filter(dir => 
                dir.estimatedTime <= filters.maxEstimatedTime
            );
        }
        
        // Cache result
        this.filterCache.set(cacheKey, filtered);
        
        return filtered;
    }

    /**
     * Get directory by ID
     */
    getDirectoryById(id) {
        return this.directories.find(dir => dir.id === id);
    }

    /**
     * Get directories by category
     */
    getDirectoriesByCategory(category) {
        return this.getDirectories({ category });
    }

    /**
     * Get high-priority directories
     */
    getHighPriorityDirectories() {
        return this.getDirectories({ priority: 'high' });
    }

    /**
     * Get easy-to-process directories (no anti-bot, no login required)
     */
    getEasyDirectories() {
        return this.getDirectories({
            difficulty: 'easy',
            excludeAntiBot: true,
            excludeLogin: true,
            excludeFees: true
        });
    }

    /**
     * Get directories suitable for automated processing
     */
    getAutomatableDirectories() {
        return this.getDirectories({
            excludeAntiBot: true,
            excludeLogin: false, // May include login if we have credentials
            maxEstimatedTime: 600 // 10 minutes max
        });
    }

    /**
     * Get processing recommendations based on criteria
     */
    getProcessingRecommendations(criteria = {}) {
        const {
            maxTime = 3600, // 1 hour max total time
            prioritizeHigh = true,
            excludeComplicated = true,
            allowFees = false
        } = criteria;

        let recommended = this.getDirectories({
            excludeAntiBot: excludeComplicated,
            excludeLogin: excludeComplicated,
            excludeFees: !allowFees
        });

        // Sort by priority and difficulty
        recommended.sort((a, b) => {
            // Priority order: high > medium > low
            const priorityOrder = { high: 3, medium: 2, low: 1 };
            const priorityDiff = priorityOrder[b.priority] - priorityOrder[a.priority];
            
            if (priorityDiff !== 0) return priorityDiff;
            
            // Difficulty order: easy > medium > hard
            const difficultyOrder = { easy: 3, medium: 2, hard: 1 };
            return difficultyOrder[b.difficulty] - difficultyOrder[a.difficulty];
        });

        // Calculate time budget and recommend subset
        let totalTime = 0;
        const timeBudgetedDirectories = [];
        
        for (const dir of recommended) {
            if (totalTime + dir.estimatedTime <= maxTime) {
                timeBudgetedDirectories.push(dir);
                totalTime += dir.estimatedTime;
            }
        }

        return {
            recommended: timeBudgetedDirectories,
            totalEstimatedTime: totalTime,
            skippedCount: recommended.length - timeBudgetedDirectories.length,
            summary: {
                high: timeBudgetedDirectories.filter(d => d.priority === 'high').length,
                medium: timeBudgetedDirectories.filter(d => d.priority === 'medium').length,
                low: timeBudgetedDirectories.filter(d => d.priority === 'low').length
            }
        };
    }

    /**
     * Get field mapping patterns for auto-form population
     */
    getFieldMappingPatterns() {
        const patterns = {
            businessName: new Set(),
            email: new Set(),
            phone: new Set(),
            website: new Set(),
            address: new Set(),
            description: new Set()
        };

        this.directories.forEach(dir => {
            Object.entries(dir.fieldMapping).forEach(([field, selector]) => {
                if (patterns[field]) {
                    patterns[field].add(selector);
                }
            });
        });

        // Convert sets to arrays and add common fallback patterns
        return {
            businessName: [
                ...Array.from(patterns.businessName),
                'input[name*="business"]',
                'input[name*="company"]',
                'input[name*="name"]',
                '#businessName',
                '#companyName',
                '.business-name',
                '.company-name'
            ],
            email: [
                ...Array.from(patterns.email),
                'input[type="email"]',
                'input[name*="email"]',
                '#email',
                '.email'
            ],
            phone: [
                ...Array.from(patterns.phone),
                'input[type="tel"]',
                'input[name*="phone"]',
                'input[name*="tel"]',
                '#phone',
                '#telephone',
                '.phone',
                '.tel'
            ],
            website: [
                ...Array.from(patterns.website),
                'input[name*="website"]',
                'input[name*="url"]',
                'input[name*="web"]',
                '#website',
                '#url',
                '.website',
                '.url'
            ],
            address: [
                ...Array.from(patterns.address),
                'input[name*="address"]',
                'textarea[name*="address"]',
                '#address',
                '.address'
            ],
            description: [
                ...Array.from(patterns.description),
                'textarea[name*="description"]',
                'textarea[name*="about"]',
                'textarea[name*="bio"]',
                '#description',
                '#about',
                '.description',
                '.about'
            ]
        };
    }

    /**
     * Get statistics about the directory registry
     */
    getStatistics() {
        if (!this.initialized) {
            return null;
        }

        const stats = {
            total: this.directories.length,
            byCategory: {},
            byPriority: {},
            byDifficulty: {},
            automatable: 0,
            requiresLogin: 0,
            hasAntiBot: 0,
            hasFees: 0
        };

        this.directories.forEach(dir => {
            // Category stats
            stats.byCategory[dir.category] = (stats.byCategory[dir.category] || 0) + 1;
            
            // Priority stats
            stats.byPriority[dir.priority] = (stats.byPriority[dir.priority] || 0) + 1;
            
            // Difficulty stats
            stats.byDifficulty[dir.difficulty] = (stats.byDifficulty[dir.difficulty] || 0) + 1;
            
            // Feature stats
            if (!dir.hasAntiBot && !dir.requiresLogin) {
                stats.automatable++;
            }
            
            if (dir.requiresLogin) {
                stats.requiresLogin++;
            }
            
            if (dir.hasAntiBot) {
                stats.hasAntiBot++;
            }
            
            if (dir.submissionFee && dir.submissionFee !== '$0' && dir.submissionFee !== 'Free') {
                stats.hasFees++;
            }
        });

        return stats;
    }

    /**
     * Clear the filter cache
     */
    clearCache() {
        this.filterCache.clear();
    }

    /**
     * Check if registry is initialized
     */
    isInitialized() {
        return this.initialized;
    }
}

// Make DirectoryRegistry available globally for service worker
globalThis.DirectoryRegistry = DirectoryRegistry;

// Create singleton instance
const directoryRegistry = new DirectoryRegistry();

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = DirectoryRegistry;
}